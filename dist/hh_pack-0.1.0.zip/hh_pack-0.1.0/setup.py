from distutils.core import setup

setup(
    name='hh_pack',
    version='0.1.0',
    packages=['ccxhhModel_inner'],
    url='20171126',
    license='',
    author='chenlw_ZCX',
    author_email='',
    description='',
    package_data={'': ['*.py', '*.pkl','*.model']},
    data_files=[('', ['setup.py'])]

)
